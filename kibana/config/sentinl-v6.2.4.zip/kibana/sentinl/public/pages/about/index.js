/*global angular*/
import About from './about.controller';

export default angular.module('apps/sentinl.aboutPage', []).controller('AboutController', About);
