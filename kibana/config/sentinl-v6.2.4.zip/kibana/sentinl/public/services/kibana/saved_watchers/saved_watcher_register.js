import './saved_watchers';

export default function savedSearchObjectFn(savedWatchersKibana) {
  return savedWatchersKibana;
}
