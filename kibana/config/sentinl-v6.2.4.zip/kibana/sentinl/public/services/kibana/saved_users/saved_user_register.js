import './saved_users';

export default function savedSearchObjectFn(savedUsersKibana) {
  return savedUsersKibana;
}
