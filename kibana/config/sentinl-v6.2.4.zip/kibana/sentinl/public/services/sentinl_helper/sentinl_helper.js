import { isObject, stripObjectPropertiesByNameRegex } from '../../lib/sentinl_helper';

class SentinlHelper {
  constructor() {}

  stripObjectPropertiesByNameRegex(obj, nameRegexp) {
    stripObjectPropertiesByNameRegex(obj, nameRegexp);
  }
}

export default SentinlHelper;
