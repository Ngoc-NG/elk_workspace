describe('Sentinl', function () {
  require('../lib/validators/__tests__/validators');
  require('../lib/__tests__/watcher_handler');
});
